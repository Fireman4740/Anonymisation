
"""Détection NER avec GLiNER."""
