
"""Optimisation RUPTA."""
