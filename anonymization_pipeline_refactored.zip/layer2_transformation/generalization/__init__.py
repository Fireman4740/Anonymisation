
"""Généralisation policy-driven."""
