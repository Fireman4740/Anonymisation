
"""Utilitaires communs."""
